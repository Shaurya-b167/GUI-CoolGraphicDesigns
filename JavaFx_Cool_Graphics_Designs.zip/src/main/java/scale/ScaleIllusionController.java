package scale;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.util.Duration;

public class ScaleIllusionController {

    @FXML
    private Pane pane;
    //Size of the scene
    private double size = 800;
    
    @FXML
    public void initialize() {
    	
    	for (int i = 0; i < 25; i++) {
    		double radius = i * 15;
            Ellipse ellipse = new Ellipse(
            		size / 2,	//x
            		size / 2, 	//y
            		radius,		//radius x
            		radius);	//radius y
            ellipse.setFill(Color.TRANSPARENT);
            ellipse.setStroke(Color.rgb(0, 255 - i * 8, 255 - i * 8));
            ellipse.setStrokeWidth(4);
            
            ScaleTransition transition = new ScaleTransition(Duration.millis(1000), ellipse);
            transition.setFromX(1);
            transition.setFromX(1);
            transition.setToX(1.1);
            transition.setToY(1.1);
            
            transition.setDelay(Duration.millis(i * 300)); // Delay increases by 5 milliseconds each time
            
            transition.setAutoReverse(true);
            transition.setInterpolator(Interpolator.LINEAR);
            transition.setCycleCount(Animation.INDEFINITE);
            
            transition.play();

            pane.getChildren().add(ellipse);
        }
    }
}
