module bolitj01.CS161JavaFXPractice {
    requires javafx.controls;
    requires javafx.fxml;

    opens translate to javafx.fxml;
    exports translate;
    
    opens rotate to javafx.fxml;
    exports rotate;
    
    opens scale to javafx.fxml;
    exports scale;
}