package rotate;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class RotateIllusionController {

	@FXML
	private Pane pane;

	private double size = 800;

	@FXML
	public void initialize() {
		
		for (int i = 0; i < 35; i++) {
			Rectangle rect = new Rectangle();
			rect.setFill(Color.TRANSPARENT);
			rect.setStroke(Color.rgb(0,i * 5,i * 5));
			rect.setStrokeWidth(2);
			rect.setHeight(10 + i * 15);
			rect.setWidth(10 + i * 15);
			rect.setX(size / 2 - rect.getWidth() / 2); // Center horizontally
			rect.setY(size / 2 - rect.getHeight() / 2); // Center vertically
						
			RotateTransition rotate = new RotateTransition(Duration.millis(4000), rect);
			rotate.setByAngle(360); // Alternate direction
			rotate.setDelay(Duration.millis(i * 40)); // Delay of 5 ms between each
			rotate.setInterpolator(Interpolator.LINEAR);
			rotate.setCycleCount(Animation.INDEFINITE);
			rotate.play();

			pane.getChildren().add(rect);
		}
		
	}
}
