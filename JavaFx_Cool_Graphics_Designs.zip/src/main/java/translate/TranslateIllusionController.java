package translate;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.util.Duration;

public class TranslateIllusionController {

    @FXML
    private Pane pane;

    //Size of the window;
    private double size = 800;
    
    @FXML
    public void initialize() {
    	
    	for (int i = 100; i > 0; i--) {
    		double radius = 5 + i;
            Ellipse ellipse = new Ellipse(
            		50.0 + i * 3.0,	//x
            		size/2, 		//y
            		radius,			//radius x
            		radius);		//radius y
            ellipse.setFill(Color.rgb(0, i * 2, i * 2));
            
            TranslateTransition transition = new TranslateTransition(Duration.millis(1000), ellipse);
            transition.setToX(600 - (6 * i)); // Move to the right
            
            transition.setDelay(Duration.millis(i * 5)); // Delay increases by 5 milliseconds each time
            
            transition.setAutoReverse(true);
            transition.setCycleCount(Animation.INDEFINITE);
            
            transition.play();

            pane.getChildren().add(ellipse);
        }
    }
}
